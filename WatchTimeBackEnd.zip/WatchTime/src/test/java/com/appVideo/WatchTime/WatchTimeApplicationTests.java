package com.appVideo.WatchTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
