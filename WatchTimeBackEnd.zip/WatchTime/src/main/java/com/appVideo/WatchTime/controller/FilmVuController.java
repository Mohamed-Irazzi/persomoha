package com.appVideo.WatchTime.controller;
//import
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins="*", allowedHeaders="*")
public class FilmVuController {

}
