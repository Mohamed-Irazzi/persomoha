package com.appVideo.WatchTime.controller;

import com.appVideo.WatchTime.DAO.FilmDAO;
import com.appVideo.WatchTime.DAO.SerieDAO;
import com.appVideo.WatchTime.MySQLConnection;
import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Serie;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.util.List;

@RestController
@CrossOrigin(origins="*", allowedHeaders="*")
public class SerieController {
    private Connection connection; //pour se connecter a la bdd
    private SerieDAO seriedao;

    //Constructeur
    public SerieController(){
        //on initialise la connection et le dao
        try{
            this.connection = MySQLConnection.getMySQLConnection();
            this.seriedao = new SerieDAO(this.connection);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    //pour avoir les infos dans la vignette du film
    @GetMapping("/vignetteSerie")
    public List<Serie> vignetteSerie(){
        String query = "select distinct photo, titre_serie, s.id_genre, date_sortie, date_fin, p.nom, p.prenom, SUM(nb_episode) as nb_episode, s.nb_saison\n" +
                "                                from series s\n" +
                "                                JOIN saisons sa ON s.id=sa.id_serie\n" +
                "                                JOIN serie_personnes sp ON s.id = sp.id_serie\n" +
                "                                JOIN personnes p ON p.id = sp.id_personne\n" +
                "                                JOIN fonctions fo ON sp.id_fonction = fo.id where fo.id=2";

        return seriedao.vignetteSeries(query);
    }


    // ca va servir a chercher une serie inchAllah
    @GetMapping("/serie/{titre}")
    @ResponseBody
    public List<Serie> getFilmByTitre(@PathVariable String titre) {
        return seriedao.findByTitre(titre);
    }
}