package com.appVideo.WatchTime.DAO;
//import
import com.appVideo.WatchTime.model.Acteur;
import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Genre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import org.hibernate.*;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class FilmDAO {
    private Connection connection; //Pour se connecter a la bdd

    //constructeur
    public FilmDAO(Connection conn){
        this.connection = conn;
    }

    // Pour la vignette du Film
    public List<Film> vignetteFilms(String query) {
        try (Statement statement = connection.createStatement()) {
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListFilms(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //sinon si la requette renvois rien bah on renvoit un tableau vide
        return new ArrayList<>();
    }


    //trouver un film avec son titre
    public List<Film> findByTitre(String titre){
        String query = "select photo, titre_film, nom_genre, date_sortie, f.duree_film, p.nom, p.prenom, synopsis, bande_annonce, origine FROM films f\n" +
                "\tJOIN film_genres fg on fg.id_film = f.id\n" +
                "    JOIN genres  g ON g.id = fg.id_genre\n" +
                "    JOIN film_personnes fp ON f.id = fp.id_film\n" +
                "    JOIN personnes p ON p.id = fp.id_personne\n" +
                "    JOIN fonctions fo ON fp.id_fonction = fo.id where fo.id=2 " +
                "    AND f.titre_film ='"+titre+"'";
        try(Statement statement = connection.createStatement()){
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListFilms(resultSet);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return new ArrayList<>();
    }


    // Mapping pour avoir l'affichage de films , independamment de la requette
    private List<Film> mapToListFilms(ResultSet resultSet) throws SQLException {
        List<Film> list = new ArrayList<>(); //on cree une liste de films
        while (resultSet.next()) {
            //on creer un objet film pour chaque film contenu dans la table renvoyer
            Film f = new Film(
                    resultSet.getString("photo"),
                    resultSet.getString("titre_film"),
                    resultSet.getString("nom_genre"),
                    resultSet.getString("date_sortie"),
                    resultSet.getString("duree_film"),
                    resultSet.getString("nom"),
                    resultSet.getString("prenom"),
                    resultSet.getString("synopsis"),
                    resultSet.getString("bande_annonce"),
                    resultSet.getString("origine")
            );
            System.out.println(f.toString());
            list.add(f); // on ajoute le film dans la liste
        }

        return list; // on retourne la liste des films
    }

    /*======================================================================================================*/

    // Pour la description du film
    public List<Film> descriptionFilms(String query) {
        try (Statement statement = connection.createStatement()) {
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListDescription(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //sinon si la requette renvois rien bah on renvoit un tableau vide
        return new ArrayList<>();
    }

    // Methode pour la description dun film
    private List<Film> mapToListDescription(ResultSet resultSet) throws SQLException {
        List<Film> list = new ArrayList<>(); //on cree une liste de films
        while (resultSet.next()) {
            //on creer un objet film pour chaque film contenu dans la table renvoyer
            Film f = new Film(
                    resultSet.getString("photo"),
                    resultSet.getString("titre_film"),
                    resultSet.getString("nom_genre"),
                    resultSet.getString("date_sortie"),
                    resultSet.getString("duree_film"),
                    resultSet.getString("nom"),
                    resultSet.getString("prenom"),
                    resultSet.getString("synopsis"),
                    resultSet.getString("bande_annonce"),
                    resultSet.getString("origine")
            );
            System.out.println(f.toString());
            list.add(f); // on ajoute le film dans la liste
        }

        return list; // on retourne la liste des films
    }

    /*========================================================================================================*/

    public List<Acteur> findActeurByFilm(String titre){
        String query = "select DISTINCT p.nom, p.prenom from films f\n" +
                "                JOIN film_personnes fp ON f.id = fp.id_film\n" +
                "                JOIN fonctions fo ON fp.id_fonction = 3\n" +
                "                JOIN personnes p ON p.id = fp.id_personne\n" +
                "                where f.titre_film ='"+titre+"'";
        try(Statement statement = connection.createStatement()){
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListActeur(resultSet);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return new ArrayList<>();
    }


    private List<Acteur> mapToListActeur(ResultSet resultSet) throws SQLException{
        List<Acteur> list = new ArrayList<>();
        while (resultSet.next()) {
            //on creer un objet film pour chaque film contenu dans la table renvoyer
            Acteur a = new Acteur(
                    resultSet.getString("nom"),
                    resultSet.getString("prenom")
            );
            list.add(a); // on ajoute le film dans la liste
        }

        return list; // on retourne la liste des films
    }


    /*==============================================================================================*/


    // pour la liste des genres dun film en question
    public List<Genre> findGenreByFilm(String titre){
        String query = "select titre_film, nom_genre FROM films f\n" +
                "                \tJOIN film_genres fg on fg.id_film = f.id\n" +
                "                  JOIN genres  g ON g.id = fg.id_genre" +
                "                  where f.titre_film='"+titre+"'";
        try(Statement statement = connection.createStatement()){
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListGenre(resultSet);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return new ArrayList<>();
    }


    //le mapping pour les genres dun film
    private List<Genre> mapToListGenre(ResultSet resultSet) throws SQLException{
        List<Genre> list = new ArrayList<>();
        while(resultSet.next()){
            Genre genre = new Genre(
                    resultSet.getString("nom_genre")
            );
            list.add(genre);
        }
        return list;
    }


}
