package com.appVideo.WatchTime.DAO;

// Imports
import com.appVideo.WatchTime.MySQLConnection;
import com.appVideo.WatchTime.model.All;
import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Serie;
import com.appVideo.WatchTime.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// Il ne s'agit plus d'une Interface, mais maintenant d'un classe car on gère la connection...
public class UserDao {
    // Pour se connecter à la BDD
    private Connection connection;

    // Constructeur
    public UserDao(Connection conn) {
        this.connection = conn;
    }


    // Pour Lister des films quelque soit le besoin
    public List<Film> listFilms(String query) {
        // On gère la connection
        try (Statement statement = connection.createStatement()) {
            // On execute la requête
            ResultSet resultSet = statement.executeQuery(query);
            // On fait le mapping avec la fonction mapToList plus bas
            return mapToListFilms(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Sinon, si la requête ne renvoit rien, alors on renvoit une Liste Vide
        return new ArrayList<>();
    }

    // Mapping pour avoir l'affichage de Films , indépendamment de la requête
    private List<Film> mapToListFilms(ResultSet resultSet) throws SQLException {
        // On crée une Liste de Films
        List<Film> list = new ArrayList<>();
        // On parcours resultSet qui est une Sorte de Liste qui va contenir à chaque fois les lignes de ma BDD, on parcours donc toutes ces lignes
        while (resultSet.next()) {
            // On crée un Objet Film pour chaque Film contenu dans la table renvoyé, càd pour chaque Film qui se trouve chacun sur une ligne
            Film f = new Film(
                    resultSet.getString("photo"),
                    resultSet.getString("titre_film")
            );
            // On ajoute le Film dans la Liste
            list.add(f);
        }
        // on retourne la Liste des Films
        return list;
    }



    // Pour Lister des Séries quelque soit le besoin
    public List<Serie> listSeries(String query) {
        // On gère la connection
        try (Statement statement = connection.createStatement()) {
            // On execute la requête
            ResultSet resultSet = statement.executeQuery(query);
            // On fait le mapping avec la fonction mapToList plus bas
            return mapToListSeries(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Sinon, si la requête ne renvoit rien, alors on renvoit une Liste Vide
        return new ArrayList<>();
    }

    // Mapping pour avoir l'affichage de Films , indépendamment de la requête
    private List<Serie> mapToListSeries(ResultSet resultSet) throws SQLException {
        // On crée une Liste de Films
        List<Serie> list = new ArrayList<>();
        // On parcours resultSet qui est une Sorte de Liste qui va contenir à chaque fois les lignes de ma BDD, on parcours donc toutes ces lignes
        while (resultSet.next()) {
            // On crée un Objet Film pour chaque Film contenu dans la table renvoyé, càd pour chaque Film qui se trouve chacun sur une ligne
            Serie s = new Serie(
                    resultSet.getString("photo"),
                    resultSet.getString("titre_serie")
            );
            // On ajoute le Film dans la Liste
            list.add(s);
        }
        // on retourne la Liste des Films
        return list;
    }



    // Pour Lister des Séries et des Films quelque soit le besoin
    public List<All> listAll(String query) {
        // On gère la connection
        try (Statement statement = connection.createStatement()) {
            // On execute la requête
            ResultSet resultSet = statement.executeQuery(query);
            // On fait le mapping avec la fonction mapToList plus bas
            return mapToListAll(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Sinon, si la requête ne renvoit rien, alors on renvoit une Liste Vide
        return new ArrayList<>();
    }

    // Mapping pour avoir l'affichage de Films , indépendamment de la requête
    private List<All> mapToListAll(ResultSet resultSet) throws SQLException {
        // On crée une Liste de Films
        List<All> list = new ArrayList<>();
        // On parcours resultSet qui est une Sorte de Liste qui va contenir à chaque fois les lignes de ma BDD, on parcours donc toutes ces lignes
        while (resultSet.next()) {
            // On crée un Objet Film pour chaque Film contenu dans la table renvoyé, càd pour chaque Film qui se trouve chacun sur une ligne
            All a = new All(
                    resultSet.getString("photo"),
                    resultSet.getString("titre")
            );
            // On ajoute le Film dans la Liste
            list.add(a);
        }
        // on retourne la Liste des Films
        return list;
    }
}
