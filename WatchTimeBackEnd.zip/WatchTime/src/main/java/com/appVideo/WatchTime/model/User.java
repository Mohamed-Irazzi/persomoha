package com.appVideo.WatchTime.model;
// Imports
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

// Va nous permettre d'identifier un fichier comme important, il s'agit ici d'une table de la BDD
//@Entity
// Nous permet tout simplement de faire correspondre le fichier avec la table correspondante de la BDD
//@Table(name="Utilisateurs",schema = "targetSchemaName")
public class User {
    //@Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    //@Column(name = "id")
    private int id;

    //@Column(name = "nom")
    private String nom;

    //@Column(name = "prenom")
    private String prenom;

    // Une sorte de Liste en JAVA qui va contenir la liste des films vus
    @ElementCollection(targetClass=Film.class)
    Set<Film> filmsVus = new HashSet<Film>();

    // Constructeur Vide
    public User(){

    }

    // Constructeur
    public User(int id, String nom, String prenom){
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Set<Film> getFilmsVus() {
        return filmsVus;
    }

    public void setFilmsVus(Set<Film> filmsVus) {
        this.filmsVus = filmsVus;
    }

    // Méthodes
    // Pour Ajouter un Film vu à la liste des Films Vus
    public void addFilmVu(Film f){
        this.filmsVus.add(f);
    }

    // Pour Supprimer un Film de la liste des Films Vus
    public void removeFilmVu(Film f){
        this.filmsVus.remove(f);
    }

    // toString
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", filmsVus=" + filmsVus.toString() +
                '}';
    }
}
