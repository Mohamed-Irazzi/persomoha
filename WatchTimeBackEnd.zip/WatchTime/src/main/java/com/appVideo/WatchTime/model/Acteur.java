package com.appVideo.WatchTime.model;

public class Acteur {
    private String nom;
    private String prenom;

    public Acteur(){

    }

    public Acteur(String nom, String prenom){
        this.nom = nom;
        this.prenom=prenom;
    }

    //getter and setter

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    @Override
    public String toString() {
        return "Acteur{" +
                "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                '}';
    }
}