package com.appVideo.WatchTime.controller;
//import
import com.appVideo.WatchTime.DAO.FilmDAO;
import com.appVideo.WatchTime.DAO.UserDao;
import com.appVideo.WatchTime.MySQLConnection;
import com.appVideo.WatchTime.model.Acteur;
import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Genre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.*;

import org.hibernate.*;

import java.sql.Connection;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins="*", allowedHeaders="*")
public class FilmController {
    private Connection connection; //pour se connecter a la bdd
    private FilmDAO filmDao;

    //Constructeur
    public FilmController(){
        //on initialise la connection et le dao
        try{
            this.connection = MySQLConnection.getMySQLConnection();
            this.filmDao = new FilmDAO(this.connection);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    //Si jamais on fait un Unique controller pour alleger
    //Alors ici cest la partie Film

    //pour lister tous les films
    @GetMapping("/films")
    public List<Film> showFilms(){
        //return filmDao.findAll();
        return null;
    }

    // Pour avoir les Infos dans la vignette du Film
    @GetMapping("/vignetteFilm")
    public List<Film> vignetteFilm(){
        String query = "select distinct photo, titre_film, date_sortie, p.nom, p.prenom, duree_film from films f "+
                "JOIN film_personnes fp ON f.id = fp.id_film " +
                "JOIN personnes p ON p.id = fp.id_personne " +
                "JOIN fonctions fo ON fp.id_fonction = fo.id where fo.id = 2";

        return filmDao.vignetteFilms(query);
    }


    // ca va servir a chercher un film inchAllah
    @GetMapping("/film/{titre}")
    @ResponseBody
    public List<Film> getFilmByTitre(@PathVariable String titre) {
        return filmDao.findByTitre(titre);
    }


    // Cela permet d'avoir les Informations nécessaires pour le descriptif d'un Film
    @GetMapping("/descriptionFilm/{titre}")
    @ResponseBody
    public List<Film> descriptionFilm(@PathVariable String titre){
        String query = "select photo, titre_film, nom_genre, date_sortie, f.duree_film, p.nom, p.prenom, bande_annonce, origine FROM films f\n" +

                "\tJOIN film_genres fg on fg.id_film = f.id\n" +
                "    JOIN genres  g ON g.id = fg.id_genre\n" +
                "    JOIN film_personnes fp ON f.id = fp.id_film\n" +
                "    JOIN personnes p ON p.id = fp.id_personne\n" +
                "    JOIN fonctions fo ON fp.id_fonction = fo.id where fo.id=2 " +
                "    AND f.titre_film ='"+titre+"'";

        return filmDao.descriptionFilms(query);
    }


    // ca va servir a chercher la liste des acteurs dun film
    @GetMapping("/film/{titre}/acteurs")
    @ResponseBody
    public List<Acteur> findActeurByFilm(@PathVariable String titre) {
        return filmDao.findActeurByFilm(titre);
    }

    //cava servir a chercher la liste des genres dun film
    @GetMapping("/film/{titre}/genres")
    @ResponseBody
    public List<Genre> findGenreByFilm(@PathVariable String titre) {
        return filmDao.findGenreByFilm(titre);
    }

}