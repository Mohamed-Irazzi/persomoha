package com.appVideo.WatchTime.model;

public class All {
    private String titre;
    private String photo;

    //constructeur
    public All(){

    }

    // Constructeur pour récupérer uniquement la photo et le titre d'une Série et d'un Film (All)
    public All(String p, String t){
        this.photo = p;
        this.titre = t;
    }


    // Getter et Setter
    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    //toString
    @Override
    public String toString() {
        return "All{" +
                "titre='" + titre + '\'' +
                ", photo='" + photo + '\'' +
                '}';
    }
}