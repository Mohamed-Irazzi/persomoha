package com.appVideo.WatchTime.controller;

// Imports
import com.appVideo.WatchTime.DAO.UserDao;
import com.appVideo.WatchTime.MySQLConnection;
import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Serie;
import com.appVideo.WatchTime.model.All;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.util.List;

@RestController
// Cet @ va nous permettre de bien afficher dans la console toutes les datas, nous pourrons donc tous les récupérer
@CrossOrigin(origins="*", allowedHeaders="*")
public class UserController {
    // Pour se connecter à la BDD
    private Connection connect;
    private UserDao userDao;

    // Constructeur
    public UserController(){
        //on initialise la connection et le dao
        try{
            this.connect = MySQLConnection.getMySQLConnection();
            this.userDao = new UserDao(this.connect);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    // On liste les Films déjà vus par l'utilisateur
    @GetMapping("/user/filmsvus")
    public List<Film> showFilmsVus(){
        String query = "select photo, titre_film from utilisateurs u " +
                "JOIN filmsvus fv ON u.id = fv.id_user " +
                "JOIN films f ON f.id = fv.id_film "+
                "ORDER BY fv.date_vision DESC";
        return userDao.listFilms(query);
    }


    // On liste les Series déjà vus par l'utilisateur
    @GetMapping("/user/seriesvues")
    public List<Serie> showSeriesVues(){
        String query = "select photo, titre_serie from utilisateurs u " +
                "JOIN seriesvues sv ON u.id = sv.id_user " +
                "JOIN series s ON s.id = sv.id_serie  "+
                "ORDER BY sv.date_vision DESC";
        return userDao.listSeries(query);
    }

    // On liste toutes les Séries et Films (All) déjà vus par l'utilisateur
    @GetMapping("/user/all")
    public List<All> showAllVus() {
        String query = "(SELECT photo,f.titre_film as titre, fv.date_vision as date_vision " +
                "from utilisateurs u " +
                "JOIN filmsvus fv ON u.id = fv.id_user " +
                "JOIN films f ON f.id = fv.id_film) " +

                " UNION " +

                "(SELECT photo, s.titre_serie as titre, sv.date_vision as date_vision " +
                "from utilisateurs u " +
                "JOIN seriesvues sv ON u.id = sv.id_user " +
                "JOIN series s ON s.id = sv.id_serie ) " +

                "ORDER BY date_vision DESC;";
        return userDao.listAll(query);
    }


    // On liste les 5 premiers Films vus pour la page d'accueil
    @GetMapping("/user/5filmsVus")
    public List<Film> showFilmsVus5(){
        String query = "select photo, titre_film from utilisateurs u " +
                "JOIN filmsvus fv ON u.id = fv.id_user " +
                "JOIN films f ON f.id = fv.id_film "+
                "ORDER BY fv.date_vision DESC LIMIT 5";
        return userDao.listFilms(query);
    }

    // Pour lister les séries deja vus par lutilisateur page accueil
    @GetMapping("/user/5seriesVues")
    public List<Serie> showSeriesVues5(){
        String query = "select photo, titre_serie from utilisateurs u " +
                "JOIN seriesvues sv ON u.id = sv.id_user " +
                "JOIN series s ON s.id = sv.id_serie " +
                "ORDER BY sv.date_vision DESC LIMIT 5";
        return userDao.listSeries(query);
    }

    // On liste les 5 premiers Films vus pour la page d'accueil
    @GetMapping("/user/listefilmsVus")
    public List<Film> showListeFilmsVus5(){
        String query = "select distinct photo, titre_film, nom_genre, date_sortie, f.duree_film, p.nom, p.prenom, synopsis, bande_annonce, origine from utilisateurs u\n" +
                "JOIN filmsvus fv ON u.id = fv.id_user \n" +
                "JOIN films f ON f.id = fv.id_film\n" +
                "JOIN film_genres fg on fg.id_film = f.id\n" +
                "JOIN genres  g ON g.id = fg.id_genre\n" +
                "JOIN film_personnes fp ON f.id = fp.id_film\n" +
                "JOIN personnes p ON p.id = fp.id_personne \n" +
                "JOIN fonctions fo ON fp.id_fonction = fo.id where fo.id=2\n" +
                "ORDER BY fv.date_vision DESC LIMIT 5";
        return userDao.listFilms(query);
    }


}
