package com.appVideo.WatchTime.model;

public class Genre{
    private String nom_genre;

    public Genre(){

    }

    // Constructeur
    public Genre(String nom){
        this.nom_genre=nom;
    }

    // Getters and Setters
    public String getNom_genre() {
        return nom_genre;
    }

    public void setNom_genre(String nom_genre) {
        this.nom_genre = nom_genre;
    }

    @Override
    public String toString() {
        return "Genre{" +
                "nom_genre='" + nom_genre + '\'' +
                '}';
    }
}