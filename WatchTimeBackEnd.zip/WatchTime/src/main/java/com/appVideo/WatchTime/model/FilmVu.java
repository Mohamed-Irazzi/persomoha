package com.appVideo.WatchTime.model;

import javax.persistence.*;

//@Entity
//@Table(name="filmsvus")
public class FilmVu{
    //@Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    //@Column(name = "id_filmsVus")
    private int id_film_vue;
    //@Column(name = "id_films")
    private int id_film;

    //contructeur
    public FilmVu(){

    }

    //constructeur deux
    public FilmVu(int id_film){
        this.id_film = id_film;
    }

    //getter and setter
    public int getId_film_vue() {
        return id_film_vue;
    }

    public void setId_film_vue(int id_film_vue) {
        this.id_film_vue = id_film_vue;
    }

    public int getId_film() {
        return id_film;
    }

    public void setId_film(int id_film) {
        this.id_film = id_film;
    }

    //toSrting
    @Override
    public String toString() {
        return "FilmVu{" +
                "id_film_vue=" + id_film_vue +
                ", id_film=" + id_film +
                '}';
    }
}
