package com.appVideo.WatchTime.model;

public class Serie extends All{
    private int id;
    private String titre;
    private int genre;
    private String photo;
    private String synopsis;
    private String bandeAnnonce;
    private String date_sortie;
    private String date_fin;
    //Nom et prenom du realisateur
    private String nom_realisateur;
    private String prenom_realisateur;
    //Nom et prenom du Producteur
    private String nom_producteur;
    private String prenom_producteur;
    private int nb_saison;
    private int nb_episode;

    //constructeur vide
    public Serie(){

    }

    // Constructeur photo pour les Séries vues
    public Serie(String p, String t){
        this.photo = p;
        this.titre = t;
    }

    // Constructeur vignette Serie
    public Serie(String t, int g, String p, String date, String fin, String nom_realisateur, String prenom_realisateur, int nb_saison, int nb_episode){
        this.titre=t;
        this.genre=g;
        this.photo=p;
        this.date_sortie=date;
        this.date_fin=fin;
        this.nom_realisateur=nom_realisateur;
        this.prenom_realisateur=prenom_realisateur;
        this.nb_saison=nb_saison;
        this.nb_episode=nb_episode;
    }

    //constructeur photo
    public Serie(String p){
        this.photo=p;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public int getGenre() {
        return genre;
    }

    public void setGenre(int genre) {
        this.genre = genre;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getBandeAnnonce() {
        return bandeAnnonce;
    }

    public void setBandeAnnonce(String bandeAnnonce) {
        this.bandeAnnonce = bandeAnnonce;
    }

    public String getDate_sortie() {
        return date_sortie;
    }

    public void setDate_sortie(String date_sortie) {
        this.date_sortie = date_sortie;
    }

    public String getNom_realisateur() {
        return nom_realisateur;
    }

    public void setNom_realisateur(String nom_realisateur) {
        this.nom_realisateur = nom_realisateur;
    }

    public String getPrenom_realisateur() {
        return prenom_realisateur;
    }

    public void setPrenom_realisateur(String prenom_realisateur) {
        this.prenom_realisateur = prenom_realisateur;
    }

    public String getNom_producteur() {
        return nom_producteur;
    }

    public void setNom_producteur(String nom_producteur) {
        this.nom_producteur = nom_producteur;
    }

    public String getPrenom_producteur() {
        return prenom_producteur;
    }

    public void setPrenom_producteur(String prenom_producteur) {
        this.prenom_producteur = prenom_producteur;
    }

    public String getDate_fin() {
        return date_fin;
    }

    public void setDate_fin(String date_fin) {
        this.date_fin = date_fin;
    }

    public int getNb_saison() {
        return nb_saison;
    }

    public void setNb_saison(int nb_saison) {
        this.nb_saison = nb_saison;
    }

    public int getNb_episode() {
        return nb_episode;
    }

    public void setNb_episode(int nb_episode) {
        this.nb_episode = nb_episode;
    }

    @Override
    public String toString() {
        return "Serie{" +
                "id=" + id +
                ", titre='" + titre + '\'' +
                ", genre=" + genre +
                ", photo='" + photo + '\'' +
                ", synopsis='" + synopsis + '\'' +
                ", bandeAnnonce='" + bandeAnnonce + '\'' +
                ", date_sortie='" + date_sortie + '\'' +
                ", date_fin='" + date_fin + '\'' +
                ", nom_realisateur='" + nom_realisateur + '\'' +
                ", prenom_realisateur='" + prenom_realisateur + '\'' +
                ", nom_producteur='" + nom_producteur + '\'' +
                ", prenom_producteur='" + prenom_producteur + '\'' +
                ", nb_saison=" + nb_saison +
                ", nb_episode=" + nb_episode +
                '}';
    }
}
