package com.appVideo.WatchTime.DAO;

import com.appVideo.WatchTime.model.Film;
import com.appVideo.WatchTime.model.Serie;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SerieDAO {
    private Connection connection; //Pour se connecter a la bdd
    //constructeur
    public SerieDAO(Connection conn){
        this.connection = conn;
    }

    public List<Serie> vignetteSeries(String query) {
        try (Statement statement = connection.createStatement()) {
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListSeries(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //sinon si la requette renvois rien bah on renvoit un tableau vide
        return new ArrayList<>();
    }

    //tas capter en mood cest pour les infos de la vignette serie
    private List<Serie> mapToListSeries(ResultSet resultSet) throws SQLException {
        List<Serie> list = new ArrayList<>(); //on cree une liste de films
        while (resultSet.next()) {
            //on creer un objet film pour chaque film contenu dans la table renvoyer
            Serie s = new Serie(
                    resultSet.getString("titre_serie"),
                    resultSet.getInt("id_genre"),
                    resultSet.getString("photo"),
                    resultSet.getString("date_sortie"),
                    resultSet.getString("date_fin"),
                    resultSet.getString("nom"),
                    resultSet.getString("prenom"),
                    resultSet.getInt("nb_saison"),
                    resultSet.getInt("nb_episode")
            );
            System.out.println(s.toString());
            list.add(s); // on ajoute le film dans la liste
        }

        return list; // on retourne la liste des films
    }


    //pour trouver une serie avec son titre
    public List<Serie> findByTitre(String titre){
        String query = "select distinct photo, titre_serie, s.id_genre, date_sortie, date_fin, p.nom, p.prenom,SUM(nb_episode) as nb_episode, s.nb_saison\n" +
                "                  from series s\n" +
                "                  JOIN saisons sa ON s.id=sa.id_serie\n" +
                "                  JOIN serie_personnes sp ON s.id = sp.id_serie\n" +
                "                  JOIN personnes p ON p.id = sp.id_personne\n" +
                "                  JOIN fonctions fo ON sp.id_fonction = fo.id where fo.id=2" +
                "                  AND titre_serie = '"+titre+"'";
        try(Statement statement = connection.createStatement()){
            //on execute la requette
            ResultSet resultSet = statement.executeQuery(query);
            //on fait le mapping avec la fonction qui est en bas
            return mapToListSeries(resultSet);

        }catch (SQLException e){
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
}
