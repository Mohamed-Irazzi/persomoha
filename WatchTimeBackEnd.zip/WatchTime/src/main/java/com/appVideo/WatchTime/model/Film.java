package com.appVideo.WatchTime.model;
//import
import javax.persistence.*;

//@Entity
//@Table(name="Films",schema = "targetSchemaName")
public class Film extends All{
    //@Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    //@Column(name = "id")
    private int id;

    //@Column(name = "titre_film")
    private String titre;

    //@Column(name = "id_genre")
    private int genre;

    // Le nom du genre
    private String nom_genre;

    //@Column(name = "photo")
    private String photo;

    //date et duree
    //@Column(name = "date_sortie")
    private String date_sortie;

    //@Column(name = "duree_film")
    private String duree_film;

    //la fonction de la personne
    private String fonction;

    //Nom et prenom du realisateur
    private String nom_realisateur;
    private String prenom_realisateur;

    //Nom et prenom du Producteur
    private String nom_producteur;
    private String prenom_producteur;

    // Origine
    private String origine;
    // Bande Annonce
    private String bande_annonce;
    // Synopsis
    private String synopsis;

    //constructeur vide
    public Film(){

    }

    // Constructeur pour récupérer uniquement la photo et le titre d'un Film
    public Film(String photo, String t){
        this.photo = photo;
        this.titre = t;
    }


    // Constructeur avec Infos vignettes
    public Film(String img, String t, String date,String nom_realisateur, String prenom_realisateur, String duree){
        this.photo = img;
        this.titre = t;
        this.date_sortie = date;
        this.nom_realisateur = nom_realisateur;
        this.prenom_realisateur = prenom_realisateur;
        this.duree_film = duree;
    }

    //constructeur avec infos Description
    public Film(String img, String t, String nom_genre, String date, String duree,String nom_realisateur, String prenom_realisateur, String synopsis, String ba, String o){
        this.photo = img;
        this.titre = t;
        this.nom_genre = nom_genre;
        this.date_sortie = date;
        this.duree_film = duree;
        this.nom_realisateur = nom_realisateur;
        this.prenom_realisateur = prenom_realisateur;
        this.synopsis = synopsis;
        this.bande_annonce = ba;
        this.origine = o;

    }

    //constructeur deux
    public Film(String t, int g){
        this.titre=t;
        this.genre=g;
    }

    //constructeur trois
    public Film(int id, String t, int g){
        this.id = id;
        this.titre=t;
        this.genre=g;
    }

    //constructeur quatre
    public Film(String img, String t, String date,String fonction){
        this.photo = img;
        this.titre=t;
        this.date_sortie=date;
        this.fonction = fonction;
    }

    //getter et setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public int getGenre() {
        return genre;
    }

    public void setGenre(int genre) {
        this.genre = genre;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getDate_sortie() {
        return date_sortie;
    }

    public void setDate_sortie(String date_sortie) {
        this.date_sortie = date_sortie;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public String getNom_realisateur() {
        return nom_realisateur;
    }

    public void setNom_realisateur(String nom_realisateur) {
        this.nom_realisateur = nom_realisateur;
    }

    public String getPrenom_realisateur() {
        return prenom_realisateur;
    }

    public void setPrenom_realisateur(String prenom_realisateur) {
        this.prenom_realisateur = prenom_realisateur;
    }

    public String getNom_producteur() {
        return nom_producteur;
    }

    public void setNom_producteur(String nom_producteur) {
        this.nom_producteur = nom_producteur;
    }

    public String getPrenom_producteur() {
        return prenom_producteur;
    }

    public void setPrenom_producteur(String prenom_producteur) {
        this.prenom_producteur = prenom_producteur;
    }

    public String getDuree_film() {
        return duree_film;
    }

    public void setDuree_film(String duree_film) {
        this.duree_film = duree_film;
    }

    public String getOrigine() {
        return origine;
    }

    public void setOrigine(String origine) {
        this.origine = origine;
    }

    public String getBande_annonce() {
        return bande_annonce;
    }

    public void setBande_annonce(String bande_annonce) {
        this.bande_annonce = bande_annonce;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getNom_genre() {
        return nom_genre;
    }

    public void setNom_genre(String nom_genre) {
        this.nom_genre = nom_genre;
    }

    // toString()
    @Override
    public String toString() {
        return "Film{" +
                "id=" + id +
                ", titre='" + titre + '\'' +
                ", genre=" + genre +
                ", nom_genre='" + nom_genre + '\'' +
                ", photo='" + photo + '\'' +
                ", date_sortie='" + date_sortie + '\'' +
                ", duree_film='" + duree_film + '\'' +
                ", fonction='" + fonction + '\'' +
                ", nom_realisateur='" + nom_realisateur + '\'' +
                ", prenom_realisateur='" + prenom_realisateur + '\'' +
                ", nom_producteur='" + nom_producteur + '\'' +
                ", prenom_producteur='" + prenom_producteur + '\'' +
                ", origine='" + origine + '\'' +
                ", bande_annonce='" + bande_annonce + '\'' +
                ", synopsis='" + synopsis + '\'' +
                '}';
    }
}
