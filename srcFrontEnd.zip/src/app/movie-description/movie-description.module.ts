import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MovieDescriptionPageRoutingModule } from './movie-description-routing.module';

import { MovieDescriptionPage } from './movie-description.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MovieDescriptionPageRoutingModule
  ],
  declarations: [MovieDescriptionPage]
})
export class MovieDescriptionPageModule {}
