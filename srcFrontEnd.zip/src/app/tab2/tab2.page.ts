import { Component } from '@angular/core';
/* On importe le module HTTP qui va nous permettre de récuperer des films ou des séries sur une API
   Ici, on le met dans le time script de tab2, car c'est sur cette page que nous allons afficher les séries et films */
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  // On va créer des variables
  
  // On va crée un boulean à False, et dès que l'on appuie sur la loupe pour chercher la Serie, il va se mettre à True
  boolean = false;

  // Variable quand la personne va entrer un titre, on va le stocker directement
  rechercheTitre = "";

  // Cette variable va nous permettre de stocker différentes informations de la Serie
  serieData = {
    photo: "",
    titre: "",
    date_sortie: "",
    date_fin: "",
    nb_saison: "",
    nb_episode: "",
    nom_realisateur: "",
    prenom_realisateur: "",
    acteurs: ""
  }


  constructor(public http: HttpClient) {

  }

  ngOnInit() {
  }


  // Méthode doRefresh, elle va rafraichir la page au début, et le setTimeout va correspondre à ce qu'il va se passer à la fin du rafraichissement
  doRefresh(event) {
    console.log('Début du Rafraichissement');

    setTimeout(() => {
      console.log('Fin du Rafraichissement');
      // Le boolean vaut false, ce qui va permettre de supprimer la Vignette
      this.boolean = false;
      // On remet la variable rechercheTitre à vide pour que la barre de recherche soit vide
      this.rechercheTitre = "";
      event.target.complete();
    }, 2000);
  }


  /* Méthode qui va permettre de lire les données d'une URL de l'API ( les prendres ), http va prendre en compte toutes les données, et get
     va prendre ces données grâce à l'url donnée */
  readApi(url: string){
    return this.http.get(url);
  }


  /* 
     La maintenant qu'on peut récupérer le nom d'une série et qu'on l'a initié avec des caractères spéciaux si il y a des espaces, alors on a
     juste à copier coller tout le code qu'on a fait dans la méthode rechercheSerie, et c'est le même principe :
        - J'ai accès au nom de la Série et l'URL le comprend
        - La méthode readApi va me permettre de prendre les données de la Serie que j'ai tappé, en effet on prend l'URL de base
          et on ajoute le nom de la Serie grâce à une concaténation
        - Avec .subscribe, je m'abonne aux données et je peux afficher toutes les données de la Serie
        - J'attribue ces données aux variables que j'ai créer précedemment
        - J'affiche ces variables dans mon code HTML et le tour est jouer
  */


  // Méthode qui va nous permettre de rechercher une Serie quand on va appuyé sur le bouton recherche
  /* Ici, on crée une constante recherche, car quand on recherche une Serie ou il y a des espaces, l'url ne le comprend pas, il doit ajouter
     des caractères spéciaux et c'est ce qu'on fait grâce à la méthode encodeURIComponent() et la méthode trim() qui remplace les espaces
     contre des caractères spéciaux */
  rechercheSerie(){
    console.log("Recherche de la Série " + this.rechercheTitre);
    const recherche = encodeURIComponent(this.rechercheTitre).trim();
    console.log("Recherche de la Série " + recherche);

    /* On prend grâce à http les données de l'URL, en gros http va permettre d'avoir accès à l'URL et readApi va prendre toutes les données de 
       l'URL et va les lire */
      this.readApi('http://localhost:8080/serie/' + recherche)

    /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
       readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'URL
    .subscribe((dataRecherche) => {
      // J'affiche dans la console toutes les données
      console.log(dataRecherche);

      // Je peux donc affecter toutes mes infos à chaque variables
      this.serieData.photo = dataRecherche[0].photo;
      this.serieData.titre = dataRecherche[0].titre;
      this.serieData.date_sortie = dataRecherche[0].date_sortie;
      this.serieData.date_fin = dataRecherche[0].date_fin;
      this.serieData.nb_saison = dataRecherche[0].nb_saison;
      this.serieData.nb_episode = dataRecherche[0].nb_episode;
      this.serieData.nom_realisateur = dataRecherche[0].nom_realisateur;
      this.serieData.prenom_realisateur = dataRecherche[0].prenom_realisateur;
      // ici ca sera les acteurs


      // On a appuyé sur la loupe pour rechercher la Serie, on met donc le boolean a True pour pouvoir afficher le contenu
      this.boolean = true;

    })

  }
}


