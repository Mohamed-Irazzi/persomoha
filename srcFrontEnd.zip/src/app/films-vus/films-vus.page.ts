import { Component, OnInit } from '@angular/core';
// Import qui va permettre de faire les Alert
import { AlertController } from '@ionic/angular';
/* On importe le module HTTP qui va nous permettre de récuperer des films ou des séries sur une API
   Ici, on le met dans le type script de tab3, car c'est sur cette page que nous allons afficher les séries et films */
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ModalController} from '@ionic/angular';  // On utilise le Modal qui est une fonctionnalité Ioni qui facilite la Navigation
// On importe MovieDescriptionPage car lorsque l'on va cliqué sur la Vignette, on devra aller vers movie-description
import { MovieDescriptionPage } from './../movie-description/movie-description.page'; 

@Component({
  selector: 'app-films-vus',
  templateUrl: './films-vus.page.html',
  styleUrls: ['./films-vus.page.scss'],
})
export class FilmsVusPage implements OnInit {

  // On va créer des variables

  // La je crée une variable photosFilmsList qui va contenir la liste de toutes mes photos (on remplira la liste quand on parcourera les données ), pareil pour Séries
  photosFilmsList: any;
  photosSeriesList: any;
  photosAllList: any;

  // Cette variable va nous permettre de stocker les différentes informations du Film
  movieData = {
    photo: ""
  }

  // Variable 
  cocheAction: boolean;
  cocheAnime: boolean;
  cocheAventure: boolean;
  cocheComedie: boolean;
  cocheDocumentaire: boolean;
  cocheDrame: boolean;
  cocheEnfant: boolean;
  cocheHorreur: boolean;
  cocheRomence: boolean;
  cocheScienceFiction: boolean;
  cocheSport: boolean;

  // Je crée une variable segment1 et segment2 qui vont correspondre aux segments que je vais créer dans le HTML
  segment1: string;
  segment2: string;


  constructor(public alertController: AlertController, public http: HttpClient) { 

    // POUR LES FILMS

    /* On prend grâce à http les données de l'url, en autres http va permettre d'aller sur Internet et readApi
       va prendre toutes les données de l'url sur Internet */
    this.readApi('http://localhost:8080/user/filmsvus')

    /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
       readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'url
    .subscribe((dataFilms) => {
      // J'affiche dans la console toutes les données
      //console.log(dataFilm);
 
      // Je dis tout simplement que ma variable créer avant va être égale au data de l'URL que j'ai lu
      this.photosFilmsList = dataFilms;

      // On voit bien que ma liste contient bien toutes mes photos
      console.log(this.photosFilmsList);
    })


    // POUR LES SERIES

    // Je procède de la même manière que pour Films
    this.readApi('http://localhost:8080/user/seriesvues')

    .subscribe((dataSeries) => {
      // J'affiche toutes les données des Séries grâce à l'URL
      //console.log(dataSeries);

      this.photosSeriesList = dataSeries;
      console.log(this.photosSeriesList);
    })


    // POUR ALL

    // Je procède de la même manière que pour Films
    this.readApi('http://localhost:8080/user/all')

    .subscribe((dataAll) => {
      // J'affiche toutes les données des Séries et des Films (All) grâce à l'URL
      //console.log(data);

      this.photosAllList = dataAll;
      console.log(this.photosAllList);
    })

  }

  ngOnInit() {
  }

  /* Fonction qui va permettre de lire les données d'une URL de l'API (les prendres), http va prendre
     en compte toutes les données, et get va prendre ces données grâce à l'url donnée */
  readApi(url: string){
    return this.http.get(url);
  }


  /* Cette méthode permet de dire que lorsque je reload la page, mon segment que j'ai crée va directement afficher la valeur
     en question, ici dans la page des vues "all", et dans la page des vues séries "all" */
  ionViewWillEnter(){
   this.segment1 = "all"; // J'affiche All en premier
   this.segment2 = "all"; // Same
  }

  // Alert permettant d'afficher les Genres dans une PopUp
  // Il faut essayer de récupérer les valeurs du tableau value quand on clique sur plusieurs checkbox
  async presentAlertGenre() {
    var alert = await this.alertController.create({
      header: 'Genres',
      inputs: [
        {
          name: 'checkboxAction',
          type: 'checkbox',
          label: 'Action',
          value: 'Action',
          checked: this.cocheAction,
          handler: () => {
            console.log(alert.inputs[0].checked);

            if(alert.inputs[0].checked !== true){
              this.cocheAction = true;
            }else{
              this.cocheAction = false;
            }

            console.log(alert.inputs[0].checked);   
          }
        },

        {
          name: 'checkboxAnime',
          type: 'checkbox',
          label: 'Anime',
          value: 'Anime',
          checked: this.cocheAnime,
          handler: () =>{
            console.log(alert.inputs[1].checked);

            if(alert.inputs[1].checked !== true){
              this.cocheAnime = true;
            }else{
              this.cocheAnime = false;
            }

            console.log(alert.inputs[1].checked);
          }
        },

        {
          name: 'checkboxAventure',
          type: 'checkbox',
          label: 'Aventure',
          value: 'Aventure',
          checked: this.cocheAventure,
          handler: () => {
            console.log(alert.inputs[2].checked);

            if(alert.inputs[2].checked !== true){
              this.cocheAventure = true;
            }else{
              this.cocheAventure = false;
            }

            console.log(alert.inputs[2].checked);   
          }
        },

        {
          name: 'checkboxComedie',
          type: 'checkbox',
          label: 'Comédie',
          value: 'Comédie',
          checked: this.cocheComedie,
          handler: () => {
            console.log(alert.inputs[3].checked);

            if(alert.inputs[3].checked !== true){
              this.cocheComedie = true;
            }else{
              this.cocheComedie = false;
            }

            console.log(alert.inputs[3].checked);   
          }
        },

        {
          name: 'checkboxDocumentaire',
          type: 'checkbox',
          label: 'Documentaire',
          value: 'Documentaire',
          checked: this.cocheDocumentaire,
          handler: () => {
            console.log(alert.inputs[4].checked);

            if(alert.inputs[4].checked !== true){
              this.cocheDocumentaire = true;
            }else{
              this.cocheDocumentaire = false;
            }

            console.log(alert.inputs[4].checked);   
          }
        },

        {
          name: 'checkboxDrame',
          type: 'checkbox',
          label: 'Drame',
          value: 'Drame',
          checked: this.cocheDrame,
          handler: () => {
            console.log(alert.inputs[5].checked);

            if(alert.inputs[5].checked !== true){
              this.cocheDrame = true;
            }else{
              this.cocheDrame = false;
            }

            console.log(alert.inputs[5].checked);   
          }
        },

        {
          name: 'checkboxEnfant',
          type: 'checkbox',
          label: 'Enfant',
          value: 'Enfant',
          checked: this.cocheEnfant,
          handler: () => {
            console.log(alert.inputs[6].checked);

            if(alert.inputs[6].checked !== true){
              this.cocheEnfant = true;
            }else{
              this.cocheEnfant = false;
            }

            console.log(alert.inputs[6].checked);   
          }
        },

        {
          name: 'checkboxHorreur',
          type: 'checkbox',
          label: 'Horreur',
          value: 'Horreur',
          checked: this.cocheHorreur,
          handler: () => {
            console.log(alert.inputs[7].checked);

            if(alert.inputs[7].checked !== true){
              this.cocheHorreur = true;
            }else{
              this.cocheHorreur = false;
            }

            console.log(alert.inputs[7].checked);   
          }
        },

        {
          name: 'checkboxRomence',
          type: 'checkbox',
          label: 'Romence',
          value: 'Romence',
          checked: this.cocheRomence,
          handler: () => {
            console.log(alert.inputs[8].checked);

            if(alert.inputs[8].checked !== true){
              this.cocheRomence = true;
            }else{
              this.cocheRomence = false;
            }

            console.log(alert.inputs[8].checked);   
          }
        },

        {
          name: 'checkboxScienceFiction',
          type: 'checkbox',
          label: 'Science Fiction',
          value: 'ScienceFiction',
          checked: this.cocheScienceFiction,
          handler: () => {
            console.log(alert.inputs[9].checked);

            if(alert.inputs[9].checked !== true){
              this.cocheScienceFiction = true;
            }else{
              this.cocheScienceFiction = false;
            }

            console.log(alert.inputs[9].checked);   
          }
        },

        {
          name: 'checkboxSport',
          type: 'checkbox',
          label: 'Sport',
          value: 'Sport',
          checked: this.cocheSport,
          handler: () => {
            console.log(alert.inputs[10].checked);

            if(alert.inputs[10].checked !== true){
              this.cocheSport = true;
            }else{
              this.cocheSport = false;
            }

            console.log(alert.inputs[10].checked);   
          }
        }
      ],
      buttons: [
        {
          text: 'Retour',
          role: 'cancel',
          handler: () => {
            console.log('Bouton Retour');
          }
        }, {
          text: 'OK',
          handler: async (alertData) => {
            console.log('Je confirme le/les genre/s en appuyant sur OK');


            /** J'ai essayé ici la fonctionnalité où dès lors que je clique sur un bouton, le bouton reste coché même après mis OK
            let resultat = await alert.onDidDismiss();
            console.log(resultat);
            // Boucle qui va nous permettre d'avoir accès à tout ce que l'on coche (ex: Si je coche Action et Anime, alors je pourrai récupérer ses données)
            var i = 0;
            while(i<alert.inputs.length){
            //console.log(resultat.data.values[i]);
                      
              var j = 0;
              while(j<resultat.data.values.length){
                if(alert.inputs[i].value === resultat.data.values[j]){
                  //console.log("Ca rentre bien dans la boucle");
                  //console.log(alert.inputs[i].checked);
                  //alert.inputs[i].checked = this.booleanTrue;
                  //console.log(alert.inputs[i].checked);
                }
                j = j + 1;
              }
              i = i + 1;
            }

            console.log(resultat);
            console.log("i: " + i + " j: " + j);
            **/
          }
        }
      ],
      //mode: 'ios'
    });

    await alert.present();

    // Me permet juste de voir les résultats sous formes de tableaux dans la console (ex: j'appuie sur Action => Ca me met action dans un tableau de values)
    let result = await alert.onDidDismiss();
    console.log(result);
    // Petite boucle qui va parcourir le tableau qui contient tous les genres que j'ai sélectionné
    for(var i=0; i<result.data.values.length; i++){
      console.log(result.data.values[i]);
    }

  }

}