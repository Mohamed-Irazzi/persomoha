import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FilmsVusPage } from './films-vus.page';

describe('FilmsVusPage', () => {
  let component: FilmsVusPage;
  let fixture: ComponentFixture<FilmsVusPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilmsVusPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FilmsVusPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
