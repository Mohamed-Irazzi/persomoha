import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FilmsVusPage } from './films-vus.page';

const routes: Routes = [
  {
    path: '',
    component: FilmsVusPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FilmsVusPageRoutingModule {}
